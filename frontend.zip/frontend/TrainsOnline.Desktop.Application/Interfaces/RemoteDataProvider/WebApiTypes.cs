﻿namespace TrainsOnline.Desktop.Application.Interfaces.RemoteDataProvider
{
    public enum WebApiTypes
    {
        REST,
        SOAP
    }
}
