﻿namespace TrainsOnline.Desktop.Application.Interfaces
{
    using AutoMapper;

    public interface ICustomMapping
    {
        void CreateMappings(Profile configuration);
    }
}
