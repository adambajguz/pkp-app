﻿namespace TrainsOnline.Desktop.Common.GeoHelpers
{
    public enum GeoCoordinatePart
    {
        Latitude,
        Longitude
    }
}
