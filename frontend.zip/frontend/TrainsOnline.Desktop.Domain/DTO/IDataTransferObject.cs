﻿namespace TrainsOnline.Desktop.Domain.DTO
{
    public interface IDataTransferObject
    {

    }
}
