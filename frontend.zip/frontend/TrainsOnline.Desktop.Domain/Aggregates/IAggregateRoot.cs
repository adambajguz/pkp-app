﻿namespace TrainsOnline.Desktop.Domain.Aggregates
{
    public interface IAggregateRoot
    {

    }
}
