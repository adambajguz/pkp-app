﻿namespace TrainsOnline.Desktop.Constants
{
    public static class SettingKeys
    {
        public static string ApiUseRestSettingKey { get; } = "ApiTypeSetting";
        public static string ApiUseLocalSettingKey { get; } = "ApiUrlTypeSetting";
    }
}
