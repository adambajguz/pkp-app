﻿namespace TrainsOnline.Desktop.ViewModels.Example
{
    using Caliburn.Micro;

    public class ExampleBlankViewModel : Screen
    {
        public ExampleBlankViewModel()
        {

        }
    }
}
