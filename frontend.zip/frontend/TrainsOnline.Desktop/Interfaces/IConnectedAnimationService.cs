﻿namespace TrainsOnline.Desktop.Interfaces
{
    public interface IConnectedAnimationService
    {
        void SetListDataItemForNextConnectedAnimation(object item);
    }
}
