﻿using TrainsOnline.Desktop.Application.Interfaces.RemoteDataProvider;

namespace TrainsOnline.Desktop.Converters
{
    public class ElementThemeToBooleanConverter : AbstractEnumToBooleanConverter<Windows.UI.Xaml.ElementTheme>
    {
        //Nothing to do!
    }

    public class WebApiTypesToBooleanConverter : AbstractEnumToBooleanConverter<WebApiTypes>
    {
        //Nothing to do!
    }
}
