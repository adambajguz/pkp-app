﻿namespace TrainsOnline.Desktop.Views.Route
{
    public interface IRouteDataGridView
    {

    }
}
