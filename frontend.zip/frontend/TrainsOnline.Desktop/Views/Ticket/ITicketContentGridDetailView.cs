﻿namespace TrainsOnline.Desktop.Views.Ticket
{
    public interface ITicketContentGridDetailView
    {
        //void SetImage(ImageSource imageSource);
    }
}
