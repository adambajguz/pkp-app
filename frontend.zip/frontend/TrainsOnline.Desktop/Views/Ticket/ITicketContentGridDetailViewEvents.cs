﻿namespace TrainsOnline.Desktop.Views.Ticket
{
    public interface ITicketContentGridDetailViewEvents
    {
        void PreviewTicketPDF();
        void DownloadTicketPDF();
    }
}
