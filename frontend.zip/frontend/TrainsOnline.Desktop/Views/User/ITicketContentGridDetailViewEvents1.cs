﻿namespace TrainsOnline.Desktop.Views.User
{
    public interface IUserDetailsViewEvents
    {
        void UpdateDetails();
        void UpdatePassword();
        void Logout();
    }
}
