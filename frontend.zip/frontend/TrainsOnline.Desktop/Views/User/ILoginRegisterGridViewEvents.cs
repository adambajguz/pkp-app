﻿namespace TrainsOnline.Desktop.Views.Ticket
{
    public interface ILoginRegisterGridViewEvents
    {
        void Login();
        void Register();
    }
}
