﻿namespace TrainsOnline.Desktop.Views.General
{
    public interface IGeneralMapViewEvents
    {
        void ResetView();
        void ZoomOut();
        void ResetZoom();
        void ZoomIn();
    }
}
