﻿namespace TrainsOnline.Desktop.Services.File
{
    public enum FileSavingResults
    {
        Ok,
        Cancelled,
        Error
    }
}
