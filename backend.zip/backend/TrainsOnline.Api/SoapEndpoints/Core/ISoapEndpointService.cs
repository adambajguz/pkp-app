﻿namespace TrainsOnline.Api.SoapEndpoints.Core
{
    public interface ISoapEndpointService
    {

    }
}
