﻿namespace TrainsOnline.Api.Configuration
{
    public static class FeaturesSettings
    {
        public static bool UseNewtonsoftJson { get; } = false;
        public static bool UseHateoas { get; } = true;
    }
}
