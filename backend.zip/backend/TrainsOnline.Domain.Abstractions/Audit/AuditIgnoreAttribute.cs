﻿namespace TrainsOnline.Domain.Abstractions.Audit
{
    using System;

    public class AuditIgnoreAttribute : Attribute
    {

    }
}
