﻿namespace TrainsOnline.Domain.Abstractions.Audit
{
    public interface IAuditableEntitiy
    {

    }
}