﻿namespace TrainsOnline.Domain.Abstractions.Base
{
    public interface IEntityInfo : IEntityCreation, IEntityLastSaved
    {

    }
}
