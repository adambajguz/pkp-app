﻿namespace TrainsOnline.Domain.Abstractions.Enums
{
    public enum AuditActions
    {
        Added,
        Modified,
        Deleted,
        Rollback
    }
}
