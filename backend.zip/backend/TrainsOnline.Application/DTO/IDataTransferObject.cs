﻿namespace TrainsOnline.Application.DTO
{
    public interface IDataTransferObject
    {

    }
}
