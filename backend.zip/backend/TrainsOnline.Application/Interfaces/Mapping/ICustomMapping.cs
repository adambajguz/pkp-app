namespace TrainsOnline.Application.Interfaces.Mapping
{
    using AutoMapper;

    public interface ICustomMapping
    {
        void CreateMappings(Profile configuration);
    }
}
