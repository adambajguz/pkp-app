﻿namespace TrainsOnline.Application.Exceptions
{
    using System;

    public class BadUserException : Exception
    {
        public BadUserException() : base()
        {

        }
    }
}
