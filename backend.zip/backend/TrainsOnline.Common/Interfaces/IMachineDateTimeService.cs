﻿namespace TrainsOnline.Common.Interfaces
{
    using System;

    public interface IMachineDateTimeService
    {
        DateTime Now { get; }
    }
}
